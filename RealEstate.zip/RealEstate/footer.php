    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?= date('Y') ?> RealEstate. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>